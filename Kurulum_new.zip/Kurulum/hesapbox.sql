-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 27 Eki 2020, 22:53:24
-- Sunucu sürümü: 10.1.47-MariaDB-0ubuntu0.18.04.1
-- PHP Sürümü: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `hesapbox`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `accounts`
--

CREATE TABLE `accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` tinyint(4) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_date` varchar(191) NOT NULL,
  `account_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_confirmation` tinyint(4) NOT NULL DEFAULT '0',
  `sold_price` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `accounts`
--

INSERT INTO `accounts` (`id`, `category_id`, `user_id`, `order`, `account_date`, `account_info`, `mobile_confirmation`, `sold_price`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL, '2020-10-04', 'test', 0, NULL, NULL, NULL),
(2, 1, NULL, NULL, '2020-06-14', 'test', 1, NULL, NULL, NULL),
(3, 1, NULL, NULL, '2020-08-06', 'test', 1, NULL, NULL, NULL),
(4, 1, NULL, NULL, '2020-07-08', 'test', 0, NULL, NULL, NULL),
(5, 1, NULL, NULL, '2020-03-02', 'test', 1, NULL, NULL, NULL),
(6, 1, NULL, NULL, '2020-04-04', 'test', 0, NULL, NULL, NULL),
(7, 1, NULL, NULL, '2020-01-24', 'test', 1, NULL, NULL, NULL),
(8, 1, NULL, NULL, '2020-03-26', 'test', 1, NULL, NULL, NULL),
(9, 1, NULL, NULL, '2020-05-01', 'test', 0, NULL, NULL, NULL),
(10, 1, NULL, NULL, '2020-04-23', 'test', 1, NULL, NULL, NULL),
(11, 1, NULL, NULL, '2020-02-17', 'test', 0, NULL, NULL, NULL),
(12, 1, NULL, NULL, '2020-01-09', 'test', 0, NULL, NULL, NULL),
(13, 1, NULL, NULL, '2020-08-26', 'test', 0, NULL, NULL, NULL),
(14, 1, NULL, NULL, '2020-09-22', 'test', 1, NULL, NULL, NULL),
(15, 1, NULL, NULL, '2020-06-12', 'test', 1, NULL, NULL, NULL),
(16, 1, NULL, NULL, '2020-05-06', 'test', 1, NULL, NULL, NULL),
(17, 1, NULL, NULL, '2020-03-06', 'test', 1, NULL, NULL, NULL),
(18, 1, NULL, NULL, '2020-02-18', 'test', 0, NULL, NULL, NULL),
(19, 1, NULL, NULL, '2020-04-03', 'test', 1, NULL, NULL, NULL),
(20, 1, NULL, NULL, '2020-02-12', 'test', 0, NULL, NULL, NULL),
(21, 1, NULL, NULL, '2020-09-24', 'test', 0, NULL, NULL, NULL),
(22, 1, NULL, NULL, '2020-08-08', 'test', 1, NULL, NULL, NULL),
(23, 1, NULL, NULL, '2020-09-27', 'test', 1, NULL, NULL, NULL),
(24, 1, NULL, NULL, '2020-01-16', 'test', 1, NULL, NULL, NULL),
(25, 1, NULL, NULL, '2020-03-05', 'test', 1, NULL, NULL, NULL),
(26, 1, NULL, NULL, '2020-02-23', 'test', 1, NULL, NULL, NULL),
(27, 1, NULL, NULL, '2020-01-10', 'test', 1, NULL, NULL, NULL),
(28, 1, NULL, NULL, '2020-05-21', 'test', 0, NULL, NULL, NULL),
(29, 1, NULL, NULL, '2020-09-08', 'test', 1, NULL, NULL, NULL),
(30, 1, NULL, NULL, '2020-04-23', 'test', 0, NULL, NULL, NULL),
(31, 1, NULL, NULL, '2020-09-10', 'test', 1, NULL, NULL, NULL),
(32, 1, NULL, NULL, '2020-01-06', 'test', 0, NULL, NULL, NULL),
(33, 1, NULL, NULL, '2020-06-21', 'test', 0, NULL, NULL, NULL),
(34, 1, NULL, NULL, '2020-07-25', 'test', 1, NULL, NULL, NULL),
(35, 1, NULL, NULL, '2020-06-13', 'test', 1, NULL, NULL, NULL),
(36, 1, NULL, NULL, '2020-02-20', 'test', 0, NULL, NULL, NULL),
(37, 1, NULL, NULL, '2020-05-16', 'test', 1, NULL, NULL, NULL),
(38, 1, NULL, NULL, '2020-05-18', 'test', 0, NULL, NULL, NULL),
(39, 1, NULL, NULL, '2020-07-19', 'test', 0, NULL, NULL, NULL),
(40, 1, NULL, NULL, '2020-06-27', 'test', 1, NULL, NULL, NULL),
(41, 1, NULL, NULL, '2020-10-11', 'test', 0, NULL, NULL, NULL),
(42, 1, NULL, NULL, '2020-01-17', 'test', 1, NULL, NULL, NULL),
(43, 1, NULL, NULL, '2020-06-05', 'test', 0, NULL, NULL, NULL),
(44, 1, NULL, NULL, '2020-02-02', 'test', 1, NULL, NULL, NULL),
(45, 1, NULL, NULL, '2020-09-23', 'test', 0, NULL, NULL, NULL),
(46, 1, NULL, NULL, '2020-02-17', 'test', 0, NULL, NULL, NULL),
(47, 1, NULL, NULL, '2020-02-05', 'test', 0, NULL, NULL, NULL),
(48, 1, NULL, NULL, '2020-02-13', 'test', 1, NULL, NULL, NULL),
(49, 1, NULL, NULL, '2020-09-16', 'test', 0, NULL, NULL, NULL),
(50, 1, NULL, NULL, '2020-10-20', 'test', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bank_lists`
--

CREATE TABLE `bank_lists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iban` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `bank_lists`
--

INSERT INTO `bank_lists` (`id`, `bank_name`, `iban`, `account_number`, `branch_code`, `owner_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'ABC Bankası', '123456789999', '112356', '123232', 'Kaan', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_description` longtext COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `price` decimal(8,2) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `order` int(11) NOT NULL DEFAULT '1',
  `sales_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `earned` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`, `image`, `seo_description`, `description`, `price`, `status`, `order`, `sales_count`, `earned`, `created_at`, `updated_at`) VALUES
(1, 'Facebook Hesapları', 'facebook-hesaplari', 'facebook-hesaplari.jpg', NULL, '<h2 style=\"text-align: center; \"><i><b>Facebook hespaları hakkında bilinmesi gerekenler</b></i></h2><ul><li style=\"text-align: center;\">&nbsp;Satın aldığınız hesapların bilgileri anında panelinize düşer.</li><li style=\"text-align: center;\">&nbsp;Hesaplar proxy ile açılmıştır</li><li style=\"text-align: center;\">&nbsp;Hesapların profil resmi vardır</li><li style=\"text-align: center;\">&nbsp;Destek talebi göndererek aklınıza takılan her konuda destek alabilirsiniz.</li></ul><h2 style=\"text-align: center;\"><b>Hesap verisi:</b></h2><p style=\"text-align: center;\">Alınan hesaplar \"email@email.com sifre\" şablonunda gözükecektir.</p>', '1.00', 1, 1, 0, '0.00', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `configs`
--

CREATE TABLE `configs` (
  `id` int(11) NOT NULL DEFAULT '1',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Title',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Description',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'logo.png',
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'favicon.png',
  `header_code` longtext COLLATE utf8mb4_unicode_ci,
  `footer_code` longtext COLLATE utf8mb4_unicode_ci,
  `recaptcha` tinyint(1) NOT NULL DEFAULT '0',
  `recaptcha_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_system` longtext COLLATE utf8mb4_unicode_ci,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `landing_area_1_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'title',
  `landing_area_1_description` longtext COLLATE utf8mb4_unicode_ci,
  `landing_area_2_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'title',
  `landing_area_2_description` longtext COLLATE utf8mb4_unicode_ci,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin@mail.com',
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '555 555 5555',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `configs`
--

INSERT INTO `configs` (`id`, `title`, `description`, `logo`, `favicon`, `header_code`, `footer_code`, `recaptcha`, `recaptcha_code`, `about_system`, `maintenance`, `landing_area_1_title`, `landing_area_1_description`, `landing_area_2_title`, `landing_area_2_description`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'Toplu Hesap Al', 'Açıklama kısmı bla bla', 'logo.png', 'favicon.png', NULL, NULL, 0, NULL, '<p><font color=\"#efefef\">\"COOYS HESAP\" bir hesap satış platformudur. Satın aldığınız hesaplar size özeldir ve bilgileri sadece size iletilir. Satın alma işleminin ardından hesap satıştan otomatik kalkar. Sitemiz bakiye yükle/harca mantığıyla çalışmaktadır. Bakiye yüklemek ve hesap satın almak için giriş yapmanız gerekmektedir. Shopier aracılığıyla 7/24 güvenli ve otomatik bir şekilde bakiye yükleyebilirsininiz. Bakiyeniz anında hesabınıza tanımlanır.</font><br></p>', 0, 'Sistem özelliklerinden bazıları', '<p><i><span>\"COOYS HESAP\" çok gelişmiş bir hesap satış platformudur. Sizlere en iyi kullanım deneyimi sunmak için bazı çok gelişmiş özelliklerimizden bahsetmek isteriz.</span></i></p><ul><li>&nbsp;Satın aldığınız hesapların bilgileri anında panelinize düşer.</li><li>&nbsp;7/24 otomatik kredi kartıyla bakiye yüklemesi yapabilirsiniz.</li><li>&nbsp;Basit sipariş ekranı ile ister tek tek, ister toplu hesap alabilirsiniz.</li><li>&nbsp;Aldığınız hesapların bilgileri direk görebilir yada xlsx olarak indirebilirsiniz.</li><li>&nbsp;Destek talebi göndererek aklınıza takılan her konuda destek alabilirsiniz.</li></ul><p>Bunların yanı sıra sistemimizdeki satın aldığınız bütün hesaplar veritabanımızda şifreli tutulur ve verileriniz güvenle saklanır.</p><p></p>', 'Neden sizden hesap almalıyım?', '<p><i>Hesap alacakların aklına takılan ilk soru \"hesaplar güvenli mi, nasıl açılıyor?\" oluyor.</i></p><p></p><p>Satın aldığınız hesaplar her seferinde farklı IP ve user-agent kullanarak takip edilemez şekilde oluşturuluyor. Hesaplarınız sadece size özeldir ve satın aldığınız hesapların giriş bilgileri bir başka kullanıcıya verilmez.</p><ul><li>&nbsp;Özenle oluşturulan kapanma riski neredeyse hiç olmayan hesaplar.</li><li>&nbsp;Satılan bir hesabın bilgisi bir başka kullanıcıya daha satılmaz. Size özeldir!</li><li>&nbsp;Hem kaliteli, hem de uygun fiyatlı hesap garantisi veriyoruz!</li></ul><p></p>', 'admin@mail.com', '555 555 5555', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `faqs`
--

INSERT INTO `faqs` (`id`, `title`, `description`, `order`, `created_at`, `updated_at`) VALUES
(1, 'Satın aldığım hesaplar kapanır mı?', 'Satın aldığınız hesaplar her seferinde özel olarak farklı IP ve user-agent kullanarak oluşturulur. Bu yüzden kapanma riski çok azdır. Satın aldığınız hesaplardan çok farklı konumlardan giriş yapmadığınız sürece güvende kalacaktır.', 1, '2020-10-27 22:59:02', '2020-10-27 22:59:02'),
(2, 'Satın aldığım hesabın giriş bilgisi ne zaman elime geçer?', 'Satın aldığınız bir hesabın giriş bilgisi sistem tarafından otomatik olarak profilinize iletilir. Herhangi bir ekstra onay işlemine tabi tutulmaz.', 2, '2020-10-27 22:59:02', '2020-10-27 22:59:02'),
(3, 'Satın aldığım hesabı başka birisi daha satın alabilir mi?', 'Satın aldığınız hesap sadece size özeldir ve bir başka kullanıcıya daha satılamaz. Siz satın alır almaz sistemden otomatik olarak silinecektir.', 3, '2020-10-27 22:59:02', '2020-10-27 22:59:02'),
(4, 'Bakiye yükledim, ne zaman hesabıma geçer?', 'Eğer kredi kartıyla online bakiye yüklerseniz 7/24 otomatik olarak anında onaylanır ve hesabınıza geçer. Eğer banka havale/eft ödemesi yaptıysanız 5-30 dakika arasında hesabınıza geçer.', 4, '2020-10-27 22:59:02', '2020-10-27 22:59:02'),
(5, 'Satın almak istediğim hesap kategorisinde hesaplar tükenmiş, ne yapabilirim?', 'Eğer hesap almak istediğiniz kategoride hesap stokları tükenmişse yeni hesap eklenmesini bekleyebilir ve destek talebi açarak bizden destek alabilirsiniz.', 5, '2020-10-27 22:59:02', '2020-10-27 22:59:02');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `funds`
--

CREATE TABLE `funds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `bank_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `funds`
--

INSERT INTO `funds` (`id`, `user_id`, `bank_id`, `name`, `amount`, `date`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'test', 125, '27-10-2020', 1, '2020-10-27 22:59:02', '2020-10-27 22:59:02');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_02_15_125440_create_accounts_table', 1),
(5, '2020_02_15_130335_create_categories_table', 1),
(6, '2020_02_15_140128_create_configs_table', 1),
(7, '2020_02_16_192454_create_tickets_table', 1),
(8, '2020_02_16_193458_create_reply_tickets_table', 1),
(9, '2020_02_18_105205_create_funds_table', 1),
(10, '2020_02_19_152206_create_bank_lists_table', 1),
(11, '2020_02_29_190918_create_pos_methods_table', 1),
(12, '2020_03_01_163914_create_online_payments_table', 1),
(13, '2020_03_11_143147_create_orders_table', 1),
(14, '2020_05_25_154359_create_faqs_table', 1),
(15, '2020_06_27_155127_create_options_table', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `online_payments`
--

CREATE TABLE `online_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `method_id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `amount` double NOT NULL,
  `payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `online_payments`
--

INSERT INTO `online_payments` (`id`, `method_id`, `user_id`, `amount`, `payment_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 125, '12345', 1, '2020-10-27 22:59:02', '2020-10-27 22:59:02');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `options`
--

CREATE TABLE `options` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `option` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `order` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `pos_methods`
--

CREATE TABLE `pos_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum` decimal(8,2) NOT NULL DEFAULT '1.00',
  `interest` tinyint(1) NOT NULL DEFAULT '1',
  `minimum_interest` decimal(8,2) NOT NULL DEFAULT '30.00',
  `payment_bonus` tinyint(1) NOT NULL DEFAULT '1',
  `payment_bonus_min_pay` decimal(8,2) NOT NULL DEFAULT '50.00',
  `payment_bonus_percent` int(11) NOT NULL DEFAULT '15',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `pos_methods`
--

INSERT INTO `pos_methods` (`id`, `name`, `secret`, `key`, `minimum`, `interest`, `minimum_interest`, `payment_bonus`, `payment_bonus_min_pay`, `payment_bonus_percent`, `status`, `created_at`, `updated_at`) VALUES
(1, 'shopier', 'secret', 'test', '10.00', 1, '30.00', 1, '50.00', 15, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `reply_tickets`
--

CREATE TABLE `reply_tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `replied_by` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `spent` decimal(8,2) NOT NULL DEFAULT '0.00',
  `account_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_role` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `password`, `amount`, `spent`, `account_count`, `user_role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Demo', 'demo@mail.com', NULL, NULL, '$2y$10$3m5mAvekzL4KPLI5UE1kye7titsQuCY0kIEjtqGqm8n3Qzl6Ke/oK', '250.00', '0.00', 0, 'admin', NULL, NULL, NULL);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `bank_lists`
--
ALTER TABLE `bank_lists`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `funds`
--
ALTER TABLE `funds`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `online_payments`
--
ALTER TABLE `online_payments`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Tablo için indeksler `pos_methods`
--
ALTER TABLE `pos_methods`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `reply_tickets`
--
ALTER TABLE `reply_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Tablo için AUTO_INCREMENT değeri `bank_lists`
--
ALTER TABLE `bank_lists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `funds`
--
ALTER TABLE `funds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Tablo için AUTO_INCREMENT değeri `online_payments`
--
ALTER TABLE `online_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `options`
--
ALTER TABLE `options`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `pos_methods`
--
ALTER TABLE `pos_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `reply_tickets`
--
ALTER TABLE `reply_tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
